import os, sqlite3, csv, io
from datetime import date, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, Response
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT")
DB_PATH = os.environ.get("DB_PATH", "rj_recovery.db")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS staff(
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'worker',
            active INTEGER NOT NULL DEFAULT 1)""")
        c.execute("""CREATE TABLE IF NOT EXISTS customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT,
            whatsapp TEXT, area TEXT, location TEXT, package TEXT, monthly_fee REAL DEFAULT 0,
            connection_fee REAL DEFAULT 0, account_no TEXT, start_date TEXT, expiry_date TEXT,
            status TEXT DEFAULT 'Active', notes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        c.execute("""CREATE TABLE IF NOT EXISTS payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL,
            amount REAL NOT NULL, paid_on TEXT NOT NULL, method TEXT, reference TEXT, received_by TEXT,
            FOREIGN KEY(customer_id) REFERENCES customers(id))""")
        admin = os.environ.get("ADMIN_USERNAME", "admin")
        password = os.environ.get("ADMIN_PASSWORD", "RJadmin@Change123")
        row = c.execute("SELECT id FROM staff WHERE username=?", (admin,)).fetchone()
        if not row:
            c.execute("INSERT INTO staff(username,password_hash,role) VALUES(?,?,?)",
                      (admin, generate_password_hash(password), "admin"))
init_db()

def login_required(f):
    @wraps(f)
    def inner(*args, **kwargs):
        if not session.get("staff_id"): return redirect(url_for("login"))
        return f(*args, **kwargs)
    return inner

def admin_required(f):
    @wraps(f)
    def inner(*args, **kwargs):
        if not session.get("staff_id"): return redirect(url_for("login"))
        if session.get("role") != "admin":
            flash("یہ کام صرف Admin کر سکتا ہے۔", "danger")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return inner

@app.after_request
def security_headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    if request.is_secure:
        resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return resp

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username=request.form.get("username","").strip()
        password=request.form.get("password","")
        with db() as c:
            user=c.execute("SELECT * FROM staff WHERE username=? AND active=1",(username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear(); session["staff_id"]=user["id"]; session["username"]=user["username"]; session["role"]=user["role"]
            return redirect(url_for("dashboard"))
        flash("Username یا password درست نہیں۔", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    today=date.today()
    with db() as c:
        total=c.execute("SELECT COUNT(*) n FROM customers").fetchone()["n"]
        active=c.execute("SELECT COUNT(*) n FROM customers WHERE status='Active'").fetchone()["n"]
        overdue=c.execute("SELECT COUNT(*) n FROM customers WHERE expiry_date IS NOT NULL AND expiry_date!='' AND expiry_date < ?",(today.isoformat(),)).fetchone()["n"]
        due=c.execute("SELECT COUNT(*) n FROM customers WHERE expiry_date BETWEEN ? AND ?",(today.isoformat(),(today+timedelta(days=2)).isoformat())).fetchone()["n"]
        month_paid=c.execute("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE substr(paid_on,1,7)=?",(today.strftime("%Y-%m"),)).fetchone()["n"]
        recent=c.execute("""SELECT p.*, c.name, c.phone FROM payments p JOIN customers c ON c.id=p.customer_id ORDER BY p.id DESC LIMIT 7""").fetchall()
        expiring=c.execute("SELECT * FROM customers WHERE expiry_date BETWEEN ? AND ? ORDER BY expiry_date LIMIT 10",
                            (today.isoformat(),(today+timedelta(days=2)).isoformat())).fetchall()
    return render_template("dashboard.html", total=total, active=active, overdue=overdue, due=due,
                           month_paid=month_paid, recent=recent, expiring=expiring)

@app.route("/customers")
@login_required
def customers():
    q=request.args.get("q","").strip()
    with db() as c:
        rows=c.execute("""SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? OR whatsapp LIKE ? OR area LIKE ? ORDER BY id DESC""",
                        (f"%{q}%",)*4).fetchall()
    return render_template("customers.html", customers=rows, q=q)

@app.route("/customers/new", methods=["GET","POST"])
@login_required
def customer_new():
    if request.method=="POST":
        f=request.form
        with db() as c:
            c.execute("""INSERT INTO customers(name,phone,whatsapp,area,location,package,monthly_fee,connection_fee,account_no,start_date,expiry_date,status,notes)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (f.get("name","").strip(),f.get("phone",""),f.get("whatsapp",""),f.get("area",""),f.get("location",""),
             f.get("package",""),float(f.get("monthly_fee") or 0),float(f.get("connection_fee") or 0),f.get("account_no",""),
             f.get("start_date",""),f.get("expiry_date",""),f.get("status","Active"),f.get("notes","")))
        flash("Customer محفوظ ہو گیا۔","success"); return redirect(url_for("customers"))
    return render_template("customer_form.html", customer=None)

@app.route("/customers/<int:cid>/edit", methods=["GET","POST"])
@login_required
def customer_edit(cid):
    with db() as c: customer=c.execute("SELECT * FROM customers WHERE id=?",(cid,)).fetchone()
    if not customer: return "Customer not found",404
    if request.method=="POST":
        f=request.form
        with db() as c:
            c.execute("""UPDATE customers SET name=?,phone=?,whatsapp=?,area=?,location=?,package=?,monthly_fee=?,connection_fee=?,account_no=?,start_date=?,expiry_date=?,status=?,notes=? WHERE id=?""",
            (f.get("name","").strip(),f.get("phone",""),f.get("whatsapp",""),f.get("area",""),f.get("location",""),f.get("package",""),
             float(f.get("monthly_fee") or 0),float(f.get("connection_fee") or 0),f.get("account_no",""),f.get("start_date",""),
             f.get("expiry_date",""),f.get("status","Active"),f.get("notes",""),cid))
        flash("Customer update ہو گیا۔","success"); return redirect(url_for("customers"))
    return render_template("customer_form.html", customer=customer)

@app.route("/customers/<int:cid>/delete", methods=["POST"])
@admin_required
def customer_delete(cid):
    with db() as c:
        c.execute("DELETE FROM payments WHERE customer_id=?",(cid,))
        c.execute("DELETE FROM customers WHERE id=?",(cid,))
    flash("Customer delete ہو گیا۔","success"); return redirect(url_for("customers"))

@app.route("/customers/<int:cid>/payments", methods=["GET","POST"])
@login_required
def customer_payments(cid):
    with db() as c:
        customer=c.execute("SELECT * FROM customers WHERE id=?",(cid,)).fetchone()
        if not customer: return "Customer not found",404
        if request.method=="POST":
            f=request.form
            c.execute("INSERT INTO payments(customer_id,amount,paid_on,method,reference,received_by) VALUES(?,?,?,?,?,?)",
                      (cid,float(f.get("amount") or 0),f.get("paid_on") or date.today().isoformat(),f.get("method","Cash"),f.get("reference",""),session.get("username","")))
            flash("Payment درج ہو گئی۔","success"); return redirect(url_for("customer_payments",cid=cid))
        payments=c.execute("SELECT * FROM payments WHERE customer_id=? ORDER BY paid_on DESC,id DESC",(cid,)).fetchall()
        paid=c.execute("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE customer_id=?",(cid,)).fetchone()["n"]
    return render_template("payments.html", customer=customer, payments=payments, paid=paid, today=date.today().isoformat())

@app.route("/staff", methods=["GET","POST"])
@admin_required
def staff():
    if request.method=="POST":
        username=request.form.get("username","").strip()
        password=request.form.get("password","")
        role=request.form.get("role","worker")
        if len(password)<10:
            flash("Password کم از کم 10 حروف کا رکھیں۔","danger")
        elif role not in ("admin","worker") or not username:
            flash("درست username اور role درج کریں۔","danger")
        else:
            try:
                with db() as c: c.execute("INSERT INTO staff(username,password_hash,role) VALUES(?,?,?)",(username,generate_password_hash(password),role))
                flash("Staff account بن گیا۔","success")
            except sqlite3.IntegrityError: flash("یہ username پہلے موجود ہے۔","danger")
        return redirect(url_for("staff"))
    with db() as c: users=c.execute("SELECT id,username,role,active FROM staff ORDER BY id").fetchall()
    return render_template("staff.html", users=users)

@app.route("/staff/<int:sid>/toggle", methods=["POST"])
@admin_required
def staff_toggle(sid):
    if sid==session.get("staff_id"):
        flash("اپنا موجودہ account بند نہیں کر سکتے۔","danger")
    else:
        with db() as c: c.execute("UPDATE staff SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?",(sid,))
        flash("Staff status تبدیل ہو گیا۔","success")
    return redirect(url_for("staff"))

@app.route("/export.csv")
@login_required
def export_csv():
    with db() as c: rows=c.execute("SELECT id,name,phone,whatsapp,area,location,package,monthly_fee,connection_fee,account_no,start_date,expiry_date,status,notes FROM customers ORDER BY id").fetchall()
    output=io.StringIO(); writer=csv.writer(output)
    writer.writerow(rows[0].keys() if rows else ["id","name","phone","whatsapp","area","location","package","monthly_fee","connection_fee","account_no","start_date","expiry_date","status","notes"])
    for r in rows: writer.writerow(list(r))
    return Response("\\ufeff"+output.getvalue(), mimetype="text/csv", headers={"Content-Disposition":"attachment; filename=rj-customers.csv"})

@app.route("/import", methods=["GET","POST"])
@login_required
def import_csv():
    if request.method=="POST":
        file=request.files.get("file")
        if not file or not file.filename.lower().endswith(".csv"):
            flash("CSV file منتخب کریں۔","danger"); return redirect(url_for("import_csv"))
        try:
            stream=io.StringIO(file.stream.read().decode("utf-8-sig"))
            reader=csv.DictReader(stream); count=0
            with db() as c:
                for r in reader:
                    if not (r.get("name") or "").strip(): continue
                    c.execute("""INSERT INTO customers(name,phone,whatsapp,area,location,package,monthly_fee,connection_fee,account_no,start_date,expiry_date,status,notes)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (r.get("name","").strip(),r.get("phone",""),r.get("whatsapp",""),r.get("area",""),r.get("location",""),r.get("package",""),
                     float(r.get("monthly_fee") or 0),float(r.get("connection_fee") or 0),r.get("account_no",""),r.get("start_date",""),r.get("expiry_date",""),r.get("status") or "Active",r.get("notes","")))
                    count+=1
            flash(f"{count} customers import ہو گئے۔","success")
        except Exception as e:
            flash("CSV format چیک کریں؛ import مکمل نہیں ہو سکا۔","danger")
        return redirect(url_for("customers"))
    return render_template("import.html")

@app.route("/health")
def health(): return {"status":"ok","app":"RJ ISP Recovery"}

if __name__=="__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT",5000)), debug=False)
