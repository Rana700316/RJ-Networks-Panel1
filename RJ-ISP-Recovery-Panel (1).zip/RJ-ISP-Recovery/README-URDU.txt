RJ ISP RECOVERY PANEL — مکمل ابتدائی پیکج

شامل فیچرز:
- Admin/Worker الگ login اور role control
- Dashboard: کل customers، active، expired، اگلے 2 دن میں expiry، ماہانہ وصولی
- Customer add/edit/search، area، WhatsApp، location، package، monthly fee، connection fee، account number
- Payment history، تاریخ، طریقہ، reference، وصول کرنے والے کا نام
- CSV export/import
- Staff accounts بنانا/بند کرنا (صرف Admin)
- Password hashing، basic security headers، responsive mobile UI
- Expiry list دکھاتا ہے؛ خودکار WhatsApp message بھیجنا اس ورژن میں شامل نہیں، اس کے لیے WhatsApp Business Cloud API اور credentials درکار ہوں گے۔

مقامی کمپیوٹر پر چلانے کا طریقہ:
1) Python 3.11 یا نیا انسٹال کریں۔
2) اس فولڈر میں terminal/CMD کھولیں۔
3) چلائیں: pip install -r requirements.txt
4) Admin password اور secret پہلے set کریں:
   Windows CMD:
   set ADMIN_USERNAME=admin
   set ADMIN_PASSWORD=ApnaStrongPassword123!
   set SECRET_KEY=ApniLambiRandomSecretKey
   python app.py
   Mac/Linux:
   export ADMIN_USERNAME=admin
   export ADMIN_PASSWORD='ApnaStrongPassword123!'
   export SECRET_KEY='ApniLambiRandomSecretKey'
   python app.py
5) Browser میں http://127.0.0.1:5000 کھولیں۔
Default admin password صرف fallback ہے: RJadmin@Change123 — deployment سے پہلے لازمی بدلیں۔

Public HTTPS + mobile data:
- صرف اس ZIP کو کھولنے سے public website نہیں بنتی۔ اسے Render یا کسی VPS پر deploy کرنا ہوگا۔
- Render پر GitHub repository connect کریں، render.yaml استعمال کریں، Environment میں ADMIN_PASSWORD لازمی set کریں (کم از کم 12+ characters)۔
- Render کی دی ہوئی https://...onrender.com URL موبائل data پر بھی کھلے گی۔ اپنے domain (مثلاً rjnetworks.com) کے لیے DNS records Render کے مطابق set کریں؛ certificate hosting provider بناتا ہے۔
- صرف IP address سے محفوظ HTTPS عام طور پر نہیں بنتا؛ public domain یا درست IP certificate اور server setup درکار ہے۔
- اس template میں SQLite DB local disk پر ہے۔ Render پر persistent disk ضروری ہے؛ متعدد instances یا production-scale کے لیے managed PostgreSQL بہتر ہے۔
- Backup باقاعدگی سے لیں۔ Customer phone/location اور payments حساس ڈیٹا ہیں؛ admin password کسی کے ساتھ share نہ کریں۔

نوٹ:
یہ deploy-ready source package ہے، live hosted panel نہیں۔ Hosting account/domain کی setup اور credentials کے بغیر میں public URL یا live IP بنا نہیں سکتا۔
